# Docker

Run SimpleReconSubdomain in a container — no local Python setup required.

## Build

There are two build paths — both produce the same `docker/simplerecon` image.

### Option A — from local code (`docker/Dockerfile`)

Build from the **repository root** (the build context must include the whole project):

```bash
docker build -t docker/simplerecon -f docker/Dockerfile .
```

### Option B — straight from GitHub (`docker/Dockerfile.remote`)

No local checkout needed — this Dockerfile clones the project itself, so the build context is ignored:

```bash
# with a throwaway context
docker build -t docker/simplerecon -f docker/Dockerfile.remote .

# fully context-less (pipe the Dockerfile in)
docker build -t docker/simplerecon - < docker/Dockerfile.remote

# nothing checked out at all — build from the raw URL
curl -sSL https://raw.githubusercontent.com/MrCl0wnLab/SimpleReconSubdomain/master/docker/Dockerfile.remote \
  | docker build -t docker/simplerecon -
```

Pin a branch/tag or a fork with build args:

```bash
docker build -t docker/simplerecon -f docker/Dockerfile.remote \
  --build-arg REF=v2.0.0 \
  --build-arg REPO_URL=https://github.com/MrCl0wnLab/SimpleReconSubdomain.git .
```

## Run

Any arguments after the image name are passed straight to `python simplerecon.py`:

```bash
# The headline example
docker run --rm docker/simplerecon -d target.com

# No arguments -> help
docker run --rm docker/simplerecon

# List sources / profiles / examples
docker run --rm docker/simplerecon --list-sources
docker run --rm docker/simplerecon --list-profiles

# Pipe-friendly (non-TTY output is automatically uncolored)
docker run --rm docker/simplerecon -d target.com --no-banner | httpx -silent

# Interactive / colored output
docker run --rm -it docker/simplerecon -d target.com --profile fast
```

## Persisting data (results, command log, watch jobs)

With `--rm` the container is ephemeral. Mount a host directory and point `--db` at it to keep results:

```bash
mkdir -p data
docker run --rm -v "$PWD/data:/app/data" \
  docker/simplerecon -d target.com --db /app/data/target.db
```

The command log and the `--watch` scheduler live in `config/system.db` inside the image. To persist them
across runs, mount a host file over it:

```bash
touch config/system.db
docker run --rm \
  -v "$PWD/data:/app/data" \
  -v "$PWD/config/system.db:/app/config/system.db" \
  docker/simplerecon -d target.com --db /app/data/target.db
```

## API keys

Keys are **not** baked into the image. Mount your `config/api_keys.json` read-only when you need
authenticated sources:

```bash
docker run --rm \
  -v "$PWD/config/api_keys.json:/app/config/api_keys.json:ro" \
  docker/simplerecon -d target.com --profile osint
```

(Without it, key-required sources simply return nothing — the tool still runs.)

## Continuous monitoring (`--watch`)

The scheduler is a long-running foreground process, so run it detached with the system DB persisted:

```bash
# Register jobs (writes to the mounted config/system.db)
docker run --rm -v "$PWD/config/system.db:/app/config/system.db" \
  docker/simplerecon -d target.com --profile fast --db /app/data/target.db --quiet \
  --watch-add "0,15,30,45 * * * *"

# Run the daemon detached
docker run -d --name recon-watch \
  -v "$PWD/data:/app/data" \
  -v "$PWD/config/system.db:/app/config/system.db" \
  docker/simplerecon --watch

docker logs -f recon-watch     # see each fired command
docker stop recon-watch        # stop the scheduler
```

> Note: scheduled jobs run **inside** the same container as `python simplerecon.py …` subprocesses.
