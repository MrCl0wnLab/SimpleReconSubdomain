from sources.base import BaseSource
from core.config import get_key


class AlienVault(BaseSource):
    NAME = 'alienvault'
    DESCRIPTION = 'AlienVault OTX passive DNS'
    API_TOKEN_IS_REQUIREMENT = False

    async def fetch(self, domain: str) -> set[str]:
        url = (
            f'https://otx.alienvault.com/api/v1/indicators/domain/{domain}/passive_dns'
        )
        subdomains: set[str] = set()
        headers = {}
        api_key = get_key('alienvault_otx')
        self.timeout = 30

        if api_key:
            headers['X-OTX-API-KEY'] = api_key

        url_list = (
            f'https://otx.alienvault.com/api/v1/indicators/domain/{domain}/url_list'
            '?limit=500&page=1'
        )

        try:
            async with self._make_client(headers=headers) as client:
                resp = await self._get(client, url)
                if resp.status_code != 200:
                    return subdomains
                for entry in resp.json().get('passive_dns', []):
                    hostname = entry.get('hostname', '')
                    if hostname:
                        subdomains.add(hostname)

                # Harvest full URLs from the separate url_list endpoint
                try:
                    url_resp = await self._get(client, url_list)
                    if url_resp.status_code == 200:
                        for entry in url_resp.json().get('url_list', []):
                            self._add_url(entry.get('url', ''), domain)
                except Exception as e:
                    self._log_exc(e)
        except Exception as e:
            self._log_exc(e)
        return self._filter(subdomains, domain)
