from sources.base import BaseSource
from core.config import get_key


class URLScan(BaseSource):
    NAME = 'urlscan'
    DESCRIPTION = 'URLScan.io scan history'
    API_TOKEN_IS_REQUIREMENT = False

    async def fetch(self, domain: str) -> set[str]:
        url = f'https://urlscan.io/api/v1/search/?q=domain:{domain}&size=200'
        subdomains: set[str] = set()
        headers = {}
        api_key = get_key('urlscan')
        if api_key:
            headers['API-Key'] = api_key

        try:
            async with self._make_client(headers=headers) as client:
                resp = await self._get(client, url)
                if resp.status_code != 200:
                    return subdomains
                for result in resp.json().get('results', []):
                    page = result.get('page', {})
                    for key in ('domain', 'ptr'):
                        val = page.get(key, '')
                        if val:
                            subdomains.add(val)
                    # Full scanned URLs (page + originating task)
                    self._add_url(page.get('url', ''), domain)
                    self._add_url(result.get('task', {}).get('url', ''), domain)
        except Exception as e:
            self._log_exc(e)
        return self._filter(subdomains, domain)
