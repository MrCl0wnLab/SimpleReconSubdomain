import csv
import io
import json
import sys
from datetime import datetime
from typing import Optional

import core.colors as colors
from output.graph import build_network_graph
from output.html_renderer import render_html
from output.report import render_markdown


def save_output(
    results: list[dict],
    fmt: str = 'txt',
    outfile: Optional[str] = None,
    quiet: bool = False,
    network_map: bool = False,
    network_html_file: Optional[str] = None,
) -> None:
    """
    Serialize *results* to the requested format and write to *outfile* or stdout.

    *results* is a list of per-domain dicts with keys:
        domain, subdomains (set), live (dict), sources (dict),
        tld_variants (set, optional)

    Formats: txt, json, csv, ndjson, html, markdown

    When *network_map* is True (or fmt == 'html'), each JSON record also carries
    a 'network' field with nodes/edges. When *network_html_file* is given, an
    HTML visualization is written there regardless of *fmt*.
    """
    # markdown primary output
    if fmt == 'markdown':
        md = render_markdown(results)
        if outfile:
            try:
                with open(outfile, 'w') as fh:
                    fh.write(md)
                    fh.write('\n')
                if not quiet:
                    print(colors.format_msg(f'\n[+] Markdown report saved to: {outfile}'))
            except OSError as exc:
                print(colors.format_msg(f'[!] Could not write to {outfile}: {exc}'), file=sys.stderr)
        else:
            print('\n' + md)
        if network_html_file:
            _write_html(results, network_html_file, quiet)
        return

    # html primary output: render and short-circuit; the side artifact
    # (network_html_file) still runs at the bottom if also set.
    if fmt == 'html':
        html_out = render_html(results)
        if outfile:
            try:
                with open(outfile, 'w') as fh:
                    fh.write(html_out)
                if not quiet:
                    print(colors.format_msg(f'\n[+] HTML network map saved to: {outfile}'))
            except OSError as exc:
                print(colors.format_msg(f'[!] Could not write to {outfile}: {exc}'), file=sys.stderr)
        else:
            print(html_out)
        if network_html_file and network_html_file != outfile:
            _write_html(results, network_html_file, quiet)
        return

    include_network = network_map or bool(network_html_file)
    segments: list[str] = []

    for result in results:
        domain = result['domain']
        subdomains: set[str] = result.get('subdomains', set())
        live: dict = result.get('live', {})
        sources: dict = result.get('sources', {})
        tld_variants: set[str] = result.get('tld_variants', set())
        extras: dict = result.get('extras', {})
        extra_hosts: set[str] = extras.get('hosts', set())
        extra_ips: set[str]   = extras.get('ips', set())
        extra_urls: set[str]  = extras.get('urls', set())
        timestamp = datetime.now().isoformat()

        if fmt == 'json':
            live_hosts: dict = {}
            for sub, info in live.items():
                if info.get('status') is not None:
                    entry = {
                        'status': info.get('status'),
                        'title': info.get('title', ''),
                        'server': info.get('server', ''),
                        'content_length': info.get('content_length', 0),
                        'url': info.get('url', ''),
                    }
                    if info.get('ips'):
                        entry['ips'] = info['ips']
                    if info.get('cloud'):
                        entry['cloud'] = info['cloud']
                    sans = info.get('tls_sans', [])
                    if sans:
                        entry['tls_sans'] = sans
                    if info.get('takeover'):
                        entry['takeover'] = info['takeover']
                    if info.get('cname'):
                        entry['cname'] = info['cname']
                    if info.get('waf'):
                        entry['waf'] = info['waf']
                    if info.get('body_hash'):
                        entry['body_hash'] = info['body_hash']
                    if info.get('response_ms') is not None:
                        entry['response_ms'] = info['response_ms']
                    live_hosts[sub] = entry

            # Detect hosts returning identical body content (wildcard / CDN farm)
            _hgroups: dict[str, list[str]] = {}
            for sub, info in live.items():
                h = info.get('body_hash')
                if h:
                    _hgroups.setdefault(h, []).append(sub)
            duplicate_bodies = {
                h: sorted(subs) for h, subs in _hgroups.items() if len(subs) > 1
            }

            data = {
                'domain': domain,
                'timestamp': timestamp,
                'total': len(subdomains),
                'subdomains': sorted(subdomains),
                'live_hosts': live_hosts,
                'sources': sources,
            }
            if tld_variants:
                data['tld_variants'] = sorted(tld_variants)
            if extra_hosts or extra_ips or extra_urls:
                data['extras'] = {}
                if extra_hosts:
                    data['extras']['hosts'] = sorted(extra_hosts)
                if extra_ips:
                    data['extras']['ips'] = sorted(extra_ips)
                if extra_urls:
                    data['extras']['urls'] = sorted(extra_urls)
            if duplicate_bodies:
                data['duplicate_bodies'] = duplicate_bodies
            if include_network:
                data['network'] = build_network_graph(result)
            segments.append(json.dumps(data, indent=2))

        elif fmt == 'csv':
            buf = io.StringIO()
            writer = csv.DictWriter(
                buf,
                fieldnames=[
                    'domain', 'subdomain', 'type',
                    'status', 'title', 'server',
                    'ips', 'cloud',
                    'tls_sans', 'takeover', 'cname', 'waf',
                    'body_hash', 'response_ms',
                ],
            )
            writer.writeheader()
            for sub in sorted(subdomains):
                live_info = live.get(sub, {})
                sans = live_info.get('tls_sans', [])
                ips = live_info.get('ips', [])
                writer.writerow({
                    'domain': domain,
                    'subdomain': sub,
                    'type': 'subdomain',
                    'status': live_info.get('status', ''),
                    'title': live_info.get('title', ''),
                    'server': live_info.get('server', ''),
                    'ips': '|'.join(ips) if ips else '',
                    'cloud': live_info.get('cloud', ''),
                    'tls_sans': '|'.join(sans) if sans else '',
                    'takeover': live_info.get('takeover', ''),
                    'cname': live_info.get('cname', ''),
                    'waf': live_info.get('waf', ''),
                    'body_hash': live_info.get('body_hash', '') or '',
                    'response_ms': live_info.get('response_ms', '') if live_info.get('response_ms') is not None else '',
                })
            for variant in sorted(tld_variants):
                writer.writerow({
                    'domain': domain,
                    'subdomain': variant,
                    'type': 'tld_variant',
                    'status': '', 'title': '', 'server': '',
                    'ips': '', 'cloud': '',
                    'tls_sans': '', 'takeover': '', 'cname': '', 'waf': '',
                })
            for host in sorted(extra_hosts):
                writer.writerow({
                    'domain': domain, 'subdomain': host, 'type': 'extra_host',
                    'status': '', 'title': '', 'server': '',
                    'ips': '', 'cloud': '', 'tls_sans': '', 'takeover': '', 'cname': '', 'waf': '',
                })
            for ip in sorted(extra_ips):
                writer.writerow({
                    'domain': domain, 'subdomain': ip, 'type': 'extra_ip',
                    'status': '', 'title': '', 'server': '',
                    'ips': '', 'cloud': '', 'tls_sans': '', 'takeover': '', 'cname': '', 'waf': '',
                })
            for url in sorted(extra_urls):
                writer.writerow({
                    'domain': domain, 'subdomain': url, 'type': 'extra_url',
                    'status': '', 'title': '', 'server': '',
                    'ips': '', 'cloud': '', 'tls_sans': '', 'takeover': '', 'cname': '', 'waf': '',
                })
            segments.append(buf.getvalue())

        elif fmt == 'ndjson':
            # One compact JSON line per subdomain — pipe-friendly
            for sub in sorted(subdomains):
                live_info = live.get(sub, {})
                record: dict = {'domain': domain, 'subdomain': sub, 'type': 'subdomain'}
                if live_info.get('status') is not None:
                    record['status'] = live_info['status']
                    if live_info.get('title'):
                        record['title'] = live_info['title']
                    if live_info.get('server'):
                        record['server'] = live_info['server']
                    if live_info.get('ips'):
                        record['ips'] = live_info['ips']
                    if live_info.get('cloud'):
                        record['cloud'] = live_info['cloud']
                    if live_info.get('tls_sans'):
                        record['tls_sans'] = live_info['tls_sans']
                    if live_info.get('takeover'):
                        record['takeover'] = live_info['takeover']
                    if live_info.get('cname'):
                        record['cname'] = live_info['cname']
                    if live_info.get('waf'):
                        record['waf'] = live_info['waf']
                    if live_info.get('body_hash'):
                        record['body_hash'] = live_info['body_hash']
                    if live_info.get('response_ms') is not None:
                        record['response_ms'] = live_info['response_ms']
                segments.append(json.dumps(record))
            for variant in sorted(tld_variants):
                segments.append(json.dumps({
                    'domain': domain, 'subdomain': variant, 'type': 'tld_variant'
                }))
            for host in sorted(extra_hosts):
                segments.append(json.dumps({'domain': domain, 'subdomain': host, 'type': 'extra_host'}))
            for ip in sorted(extra_ips):
                segments.append(json.dumps({'domain': domain, 'subdomain': ip, 'type': 'extra_ip'}))
            for url in sorted(extra_urls):
                segments.append(json.dumps({'domain': domain, 'subdomain': url, 'type': 'extra_url'}))

        else:  # txt (default)
            lines = list(sorted(subdomains))
            if tld_variants:
                if not quiet:
                    lines.append('')
                    lines.append('# TLD variants')
                lines.extend(sorted(tld_variants))
            if extra_hosts:
                if not quiet:
                    lines.append('')
                    lines.append('# External hosts')
                lines.extend(sorted(extra_hosts))
            if extra_ips:
                if not quiet:
                    lines.append('')
                    lines.append('# IPs')
                lines.extend(sorted(extra_ips))
            if extra_urls:
                if not quiet:
                    lines.append('')
                    lines.append('# URLs')
                lines.extend(sorted(extra_urls))
            segments.append('\n'.join(lines))

    output = '\n'.join(segments)

    if outfile:
        try:
            with open(outfile, 'w') as fh:
                fh.write(output)
                if fmt != 'ndjson':
                    fh.write('\n')
            if not quiet:
                print(colors.format_msg(f'\n[+] Output saved to: {outfile}'))
        except OSError as exc:
            print(colors.format_msg(f'[!] Could not write to {outfile}: {exc}'), file=sys.stderr)
    else:
        if output:
            print('\n' + output)

    if network_html_file:
        _write_html(results, network_html_file, quiet)


def _write_html(results: list[dict], path: str, quiet: bool) -> None:
    try:
        with open(path, 'w') as fh:
            fh.write(render_html(results))
        if not quiet:
            print(colors.format_msg(f'[+] HTML network map saved to: {path}'))
    except OSError as exc:
        print(colors.format_msg(f'[!] Could not write to {path}: {exc}'), file=sys.stderr)
