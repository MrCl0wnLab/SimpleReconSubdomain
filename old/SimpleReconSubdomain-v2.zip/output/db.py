"""
Per-target results store for SimpleReconSubdomain.

A single `--db FILE` is used as both the comparison source (input) and the save
target (output). It holds **only recon results** (system/log data lives in the
fixed `config/system.db`, see core/system_db.py). The store is append-only;
rows are keyed by `domain`, so "known" lookups use `SELECT DISTINCT` and the
comparison baseline for `--db-news` is the union of everything ever stored for a
domain.

Schema (auto-created on first use)
----------------------------------
  subdomains   — discovered subdomains + optional live-check metadata
  tld_variants — TLD variant results
  extras       — out-of-scope hosts/IPs (populated only at -v 3)
  urls         — collected URLs tagged with the source that found them

Public API
----------
init_db(path)              — create schema (migrating legacy DBs) if needed
save_result(path, result)  — persist one Engine result dict
load_known(path, domain)   — dict of sets of all previously seen values
filter_new(result, known)  — copy of result with only values absent from known
list_subdomains/list_urls/list_extras — read-only helpers for --db-list

Pure stdlib (`sqlite3`); no third-party dependency.
"""
from __future__ import annotations

import json
import sqlite3
from datetime import datetime, timezone

_SCHEMA = """\
CREATE TABLE IF NOT EXISTS subdomains (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    domain      TEXT    NOT NULL,
    subdomain   TEXT    NOT NULL,
    first_seen  TEXT    NOT NULL,
    status      INTEGER,
    title       TEXT,
    server      TEXT,
    ips         TEXT,
    cloud       TEXT,
    tls_sans    TEXT,
    takeover    TEXT,
    cname       TEXT,
    waf         TEXT,
    body_hash   TEXT,
    response_ms INTEGER
);

CREATE TABLE IF NOT EXISTS tld_variants (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    domain     TEXT    NOT NULL,
    variant    TEXT    NOT NULL,
    first_seen TEXT    NOT NULL
);

CREATE TABLE IF NOT EXISTS extras (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    domain     TEXT    NOT NULL,
    type       TEXT    NOT NULL,
    value      TEXT    NOT NULL,
    first_seen TEXT    NOT NULL
);

CREATE TABLE IF NOT EXISTS urls (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    domain     TEXT NOT NULL,
    url        TEXT NOT NULL,
    source     TEXT,
    first_seen TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_sub_domain   ON subdomains(domain);
CREATE INDEX IF NOT EXISTS idx_sub_value    ON subdomains(subdomain);
CREATE INDEX IF NOT EXISTS idx_tld_domain   ON tld_variants(domain);
CREATE INDEX IF NOT EXISTS idx_extra_domain ON extras(domain, type);
CREATE INDEX IF NOT EXISTS idx_url_domain   ON urls(domain);
"""

# Categories returned by load_known() and filtered by filter_new()
_KNOWN_KEYS = ('subdomains', 'tld_variants', 'hosts', 'ips', 'urls')

# Child tables and their canonical (results-only, no scan_id) column lists — used
# by the legacy migration to copy rows into freshly-created flat tables.
_CHILD_COLUMNS = {
    'subdomains':   ('id', 'domain', 'subdomain', 'first_seen',
                     'status', 'title', 'server', 'ips', 'cloud', 'tls_sans',
                     'takeover', 'cname', 'waf', 'body_hash', 'response_ms'),
    'tld_variants': ('id', 'domain', 'variant', 'first_seen'),
    'extras':       ('id', 'domain', 'type', 'value', 'first_seen'),
    'urls':         ('id', 'domain', 'url', 'source', 'first_seen'),
}

# Legacy parent tables removed by the migration (command audit now lives in system.db)
_LEGACY_PARENTS = ('history', 'scans', 'command_history')


def _connect(path: str) -> sqlite3.Connection:
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    return conn


def init_db(path: str) -> None:
    """Create the schema in *path*, migrating a legacy (history/scan_id) DB if found."""
    conn = sqlite3.connect(path)
    conn.isolation_level = None  # autocommit; explicit BEGIN/COMMIT in the migration
    try:
        conn.execute('PRAGMA journal_mode = WAL')
        tables = {r[0] for r in conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table'"
        )}
        sub_cols = set()
        if 'subdomains' in tables:
            sub_cols = {r[1] for r in conn.execute('PRAGMA table_info(subdomains)')}
        legacy = (
            any(t in tables for t in _LEGACY_PARENTS)
            or 'scan_id' in sub_cols
        )
        if legacy:
            _migrate_legacy(conn, tables)
        else:
            conn.executescript(_SCHEMA)
    finally:
        conn.close()


def _migrate_legacy(conn: sqlite3.Connection, tables: set[str]) -> None:
    """Migrate a legacy results DB to the flat, results-only schema.

    Rebuilds each child table without its `scan_id` column (results are keyed by
    `domain`), then drops the legacy parent tables (`history`/`scans`/
    `command_history`) — command audit now lives in `config/system.db`. All
    result rows are preserved.
    """
    present_children = [t for t in _CHILD_COLUMNS if t in tables]

    conn.execute('PRAGMA foreign_keys = OFF')
    try:
        conn.execute('BEGIN')
        # 1. move legacy children aside
        for t in present_children:
            conn.execute(f'ALTER TABLE {t} RENAME TO _mig_{t}')
        # 2. build the new flat schema
        for stmt in _SCHEMA.split(';'):
            if stmt.strip():
                conn.execute(stmt)
        # 3. copy result rows back (canonical columns only — scan_id is dropped)
        for t in present_children:
            cols = ', '.join(_CHILD_COLUMNS[t])
            conn.execute(f'INSERT INTO {t} ({cols}) SELECT {cols} FROM _mig_{t}')
            conn.execute(f'DROP TABLE _mig_{t}')
        # 4. drop legacy parent tables
        for parent in _LEGACY_PARENTS:
            if parent in tables:
                conn.execute(f'DROP TABLE {parent}')
        conn.execute('COMMIT')
    except Exception:
        conn.execute('ROLLBACK')
        raise
    finally:
        conn.execute('PRAGMA foreign_keys = ON')


def save_result(path: str, result: dict) -> None:
    """Persist a single Engine result dict (results only) into the database at *path*."""
    init_db(path)

    domain: str       = result.get('domain', '')
    subdomains: set   = result.get('subdomains', set()) or set()
    live: dict        = result.get('live', {}) or {}
    tld_variants: set = result.get('tld_variants', set()) or set()
    extras: dict      = result.get('extras', {}) or {}
    urls: dict        = result.get('urls', {}) or {}
    ts = datetime.now(timezone.utc).isoformat()

    conn = _connect(path)
    try:
        with conn:
            for sub in subdomains:
                info = live.get(sub, {}) or {}
                ips  = info.get('ips') or []
                sans = info.get('tls_sans') or []
                conn.execute(
                    """INSERT INTO subdomains
                       (domain, subdomain, first_seen,
                        status, title, server, ips, cloud, tls_sans,
                        takeover, cname, waf, body_hash, response_ms)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    (
                        domain, sub, ts,
                        info.get('status'),
                        info.get('title'),
                        info.get('server'),
                        json.dumps(ips) if ips else None,
                        info.get('cloud'),
                        json.dumps(sans) if sans else None,
                        info.get('takeover'),
                        info.get('cname'),
                        info.get('waf'),
                        info.get('body_hash'),
                        info.get('response_ms'),
                    ),
                )

            for variant in tld_variants:
                conn.execute(
                    'INSERT INTO tld_variants (domain, variant, first_seen) VALUES (?, ?, ?)',
                    (domain, variant, ts),
                )

            for etype, values in (
                ('host', extras.get('hosts', set())),
                ('ip',   extras.get('ips', set())),
            ):
                for val in (values or set()):
                    conn.execute(
                        'INSERT INTO extras (domain, type, value, first_seen) VALUES (?, ?, ?, ?)',
                        (domain, etype, val, ts),
                    )

            # URLs go to their own table, tagged with the source that found them
            for url, src in urls.items():
                conn.execute(
                    'INSERT INTO urls (domain, url, source, first_seen) VALUES (?, ?, ?, ?)',
                    (domain, url, src, ts),
                )
    finally:
        conn.close()


def load_known(path: str, domain: str) -> dict[str, set[str]]:
    """
    Return every value ever stored for *domain*, grouped by category.

    Keys: 'subdomains', 'tld_variants', 'hosts', 'ips', 'urls'. Missing DB file
    (or any read error) yields empty sets, so a first run treats everything as new.
    """
    known: dict[str, set[str]] = {k: set() for k in _KNOWN_KEYS}
    # Ensure schema/migration is done before opening our read connection, so a
    # heavy legacy migration never runs while this connection is mid-use.
    try:
        init_db(path)
        conn = _connect(path)
    except sqlite3.Error:
        return known
    try:
        for row in conn.execute(
            'SELECT DISTINCT subdomain FROM subdomains WHERE domain = ?', (domain,)
        ):
            known['subdomains'].add(row['subdomain'])
        for row in conn.execute(
            'SELECT DISTINCT variant FROM tld_variants WHERE domain = ?', (domain,)
        ):
            known['tld_variants'].add(row['variant'])
        for row in conn.execute(
            'SELECT DISTINCT type, value FROM extras WHERE domain = ?', (domain,)
        ):
            # 'url' kept for backward compat with DBs written before the urls table
            bucket = {'host': 'hosts', 'ip': 'ips', 'url': 'urls'}.get(row['type'])
            if bucket:
                known[bucket].add(row['value'])
        for row in conn.execute(
            'SELECT DISTINCT url FROM urls WHERE domain = ?', (domain,)
        ):
            known['urls'].add(row['url'])
    except sqlite3.Error:
        pass
    finally:
        conn.close()
    return known


def _list_query(path: str, sql: str, domain: str | None) -> list:
    """Run a read-only listing query, optionally filtered by domain. Empty on error."""
    try:
        conn = _connect(path)
    except sqlite3.Error:
        return []
    try:
        if domain:
            rows = conn.execute(sql + ' WHERE domain = ?' + _ORDER[sql], (domain,)).fetchall()
        else:
            rows = conn.execute(sql + _ORDER[sql]).fetchall()
        return [tuple(r) for r in rows]
    except sqlite3.Error:
        return []
    finally:
        conn.close()


# Base SELECTs (without WHERE/ORDER) mapped to their ORDER BY clause
_SQL_SUBS   = 'SELECT DISTINCT subdomain FROM subdomains'
_SQL_URLS   = 'SELECT DISTINCT url, source FROM urls'
_SQL_EXTRAS = 'SELECT DISTINCT type, value FROM extras'
_ORDER = {
    _SQL_SUBS:   ' ORDER BY subdomain',
    _SQL_URLS:   ' ORDER BY url',
    _SQL_EXTRAS: ' ORDER BY type, value',
}


def list_subdomains(path: str, domain: str | None = None) -> list[str]:
    """All distinct discovered subdomains stored in *path* (optionally one target)."""
    return [r[0] for r in _list_query(path, _SQL_SUBS, domain)]


def list_urls(path: str, domain: str | None = None) -> list[tuple[str, str]]:
    """All distinct collected URLs as (url, source)."""
    return _list_query(path, _SQL_URLS, domain)


def list_extras(path: str, domain: str | None = None) -> list[tuple[str, str]]:
    """All distinct extras as (type, value) — hosts and IPs."""
    return _list_query(path, _SQL_EXTRAS, domain)


def filter_new(result: dict, known: dict[str, set[str]]) -> dict:
    """
    Return a copy of *result* containing only values absent from *known*.

    Filters subdomains, prunes live metadata to the surviving subdomains, filters
    TLD variants, and filters each extras category. `domain` and `sources` are
    preserved unchanged.
    """
    known_subs    = known.get('subdomains', set())
    known_tld     = known.get('tld_variants', set())
    known_hosts   = known.get('hosts', set())
    known_ips     = known.get('ips', set())
    known_urls    = known.get('urls', set())

    new_subs = {s for s in (result.get('subdomains') or set()) if s not in known_subs}

    live = result.get('live', {}) or {}
    new_live = {s: info for s, info in live.items() if s in new_subs}

    new_tld = {v for v in (result.get('tld_variants') or set()) if v not in known_tld}

    extras = result.get('extras', {}) or {}
    new_extras: dict[str, set] = {}
    filtered_hosts = {h for h in extras.get('hosts', set()) if h not in known_hosts}
    filtered_ips   = {i for i in extras.get('ips', set()) if i not in known_ips}
    filtered_urls  = {u for u in extras.get('urls', set()) if u not in known_urls}
    if filtered_hosts:
        new_extras['hosts'] = filtered_hosts
    if filtered_ips:
        new_extras['ips'] = filtered_ips
    if filtered_urls:
        new_extras['urls'] = filtered_urls

    # Dedicated url -> source map (persisted to the urls table)
    new_urls = {
        u: s for u, s in (result.get('urls') or {}).items() if u not in known_urls
    }

    return {
        'domain': result.get('domain', ''),
        'subdomains': new_subs,
        'live': new_live,
        'sources': result.get('sources', {}),
        'tld_variants': new_tld,
        'extras': new_extras,
        'urls': new_urls,
    }
