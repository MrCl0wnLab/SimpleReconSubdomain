#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# SimpleReconSubdomain v2
# https://github.com/MrCl0wnLab/SimpleReconSubdomain
#
# WARNING
# +------------------------------------------------------------------------------+
# |  [!] Legal disclaimer: Usage of SimpleReconSubdomain for attacking           |
# |  targets without prior mutual consent is illegal.                            |
# |  It is the end user's responsibility to obey all applicable                  |
# |  local, state and federal laws.                                              |
# |  Developers assume no liability and are not responsible for any misuse or    |
# |  damage caused by this program.                                              |
# +------------------------------------------------------------------------------+

import asyncio
import sys

from cli.parser import (
    build_parser, print_sources, print_profiles, print_examples,
    print_db_list, print_watch_list,
)
from core.engine import Engine
import core.colors as colors

BANNER_SIMPLE = rf"""
                                                 
                 ▄▄▄▄▄▄▄                    ▄▄       ▄▄▄▄▄▄▄                           
                █████▀▀▀ ▀▀                 ██       ███▀▀███▄                       
                 ▀████▄  ██  ███▄███▄ ████▄ ██ ▄█▀█▄ ███▄▄███▀ ▄█▀█▄ ▄████ ▄███▄ ████▄ 
                   ▀████ ██  ██ ██ ██ ██ ██ ██ ██▄█▀ ███▀▀██▄  ██▄█▀ ██    ██ ██ ██ ██ 
                ███████▀ ██▄ ██ ██ ██ ████▀ ██ ▀█▄▄▄ ███  ▀███ ▀█▄▄▄ ▀████ ▀███▀ ██ ██ v2   
                                      ██"""
BANNER_SUB = rf"""                                                                                 
        ░██████             ██        ░███████                                         ░██           
     ░██   ░██             ░██        ░██   ░██                                                      
    ░██         ░██    ░██ ░████████  ░██    ░██  ░███████  ░█████████████   ░██████   ░██░████████  
     ░████████  ░██    ░██ ░██    ░██ ░██    ░██ ░██    ░██ ░██   ░██   ░██       ░██  ░██░██    ░██ 
            ░██ ░██    ░██ ░██    ░██ ░██    ░██ ░██    ░██ ░██   ░██   ░██  ░███████  ░██░██    ░██ 
     ░██   ░██  ░██   ░███ ░███   ░██ ░██   ░██  ░██    ░██ ░██   ░██   ░██ ░██   ░██  ░██░██    ░██ 
      ░██████    ░█████░██ ░██░█████  ░███████    ░███████  ░██   ░██   ░██  ░█████░██ ░██░██    ░██                        
"""
BANNER_BUTTON = rf"""                                                                                             
                                                        {colors.bold('By: MrCl0wn')} {colors.white(f"/ https://blog.mrcl0wn.com")}
                                                                      {colors.white("https://twitter.com/MrCl0wnLab")}
                                                                      {colors.white("https://github.com/MrCl0wnLab")}
"""

BANNER = colors.red(BANNER_SIMPLE) + colors.cyan(BANNER_SUB) + colors.white(BANNER_BUTTON)


def main() -> None:
    # Pre-initialize colors before building the parser so --help output is colored.
    # Check sys.argv directly since args are not parsed yet.
    colors.init(no_color='--no-color' in sys.argv)

    parser = build_parser()
    args = parser.parse_args()

    if args.list_sources:
        print_sources()
        sys.exit(0)

    if args.list_profiles:
        print_profiles()
        sys.exit(0)

    if args.list_examples:
        print_examples()
        sys.exit(0)

    if getattr(args, 'db_list', None):
        # 'history' reads the fixed config/system.db; the rest read the --db file
        if args.db_list != 'history' and not getattr(args, 'db', None):
            print(colors.format_msg(f'[!] --db-list {args.db_list} requires --db FILE.'))
            sys.exit(1)
        print_db_list(args.db_list, getattr(args, 'db', None), args.domain)
        sys.exit(0)

    if getattr(args, 'watch_list', False):
        print_watch_list()
        sys.exit(0)

    if getattr(args, 'watch_clear', False):
        from core import system_db
        n = system_db.clear_watch_jobs()
        print(colors.format_msg(f'[+] [watch] removed {n} job(s).'))
        sys.exit(0)

    if getattr(args, 'watch_del', None) is not None:
        from core import system_db
        if system_db.delete_watch_job(args.watch_del):
            print(colors.format_msg(f'[+] [watch] deleted job #{args.watch_del}.'))
            sys.exit(0)
        print(colors.format_msg(f'[!] [watch] no job with id {args.watch_del}.'))
        sys.exit(1)

    if getattr(args, 'watch_add', None):
        from core.watch import build_command_string, parse_cron
        from core import system_db
        try:
            parse_cron(args.watch_add)  # validate the 5-field cron expression
            cmd = build_command_string(sys.argv)
            system_db.add_watch_job(cmd, args.watch_add)
        except ValueError as exc:
            print(colors.format_msg(f'[!] [watch] invalid cron: {exc}'))
            sys.exit(1)
        print(colors.format_msg(
            f'[+] [watch] registered @ {args.watch_add} -> {system_db.SYSTEM_DB}\n    {cmd}'
        ))
        sys.exit(0)

    if getattr(args, 'watch', False):
        from core.watch import run_daemon
        run_daemon()
        sys.exit(0)

    # Apply run-config preset before engine init (CLI flags already parsed, so
    # they will override config values via apply_run_config's default-comparison).
    if getattr(args, 'config', None):
        from core.run_config import load_run_config, apply_run_config
        cfg = load_run_config(args.config)
        apply_run_config(args, cfg)

    if getattr(args, 'db_news', False) and not getattr(args, 'db', None):
        print(colors.format_msg('[!] --db-news requires --db FILE (the database to compare against and save to).'))
        sys.exit(1)

    if not args.domain and not args.list and not getattr(args, 'stdin', False) and sys.stdin.isatty():
        parser.print_help()
        sys.exit(1)

    # --no-banner implies quiet mode: suppress banner + all process messages
    if getattr(args, 'no_banner', False):
        args.quiet = True

    if not args.quiet:
        print(colors.cyan(BANNER))

    engine = Engine(args)
    try:
        asyncio.run(engine.run())
    except KeyboardInterrupt:
        print('\n' + colors.format_msg('[!] Interrupted by user.'))
        sys.exit(0)


if __name__ == '__main__':
    main()
